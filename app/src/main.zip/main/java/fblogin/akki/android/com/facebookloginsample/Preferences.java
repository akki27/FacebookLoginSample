package fblogin.akki.android.com.facebookloginsample;

/**
 * Created by SadyAkki on 6/3/2017.
 */

public abstract class Preferences {

    private Preferences() {
    }


    public static String FB_LOGIN_PREFERENCE_KEY = "fbLoginPreferenceKey";
    public static String DEFAULT_AUTH_DATA = "noAuthToken";

    public static String OLD_FACE_DATA_PREFERENCE_KEY = "currDataPreferenceKey";
    public static String OLD_FACE_DATA = "oldFaceData";




}

